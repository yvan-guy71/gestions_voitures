<?php $__env->startSection('title', 'Liste des Réparations'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="flex-between mb-6" style="margin-top: 2rem;">
        <div>
            <h2 class="section-title" style="text-align: left; margin-bottom: 0.5rem;">Suivi des Réparations</h2>
            <p class="text-gray-500">Historique et interventions en cours</p>
        </div>
        <a href="<?php echo e(route('reparations.create')); ?>" class="btn btn-primary">
            <span>+</span> Ajouter une réparation
        </a>
    </div>

    <?php if($reparations->isEmpty()): ?>
        <div class="empty-state">
            <div style="font-size: 3rem; margin-bottom: 1rem; color: var(--primary-color);"><i class="fas fa-wrench"></i></div>
            <h3>Aucune réparation enregistrée</h3>
            <p>Commencez à suivre les maintenances et réparations.</p>
            <a href="<?php echo e(route('reparations.create')); ?>" class="btn btn-primary mt-4"><i class="fas fa-plus"></i> Ajouter une réparation</a>
        </div>
    <?php else: ?>
        <div class="grid-container">
            <?php $__currentLoopData = $reparations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reparation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modern-card">
                    <div class="card-image-header" style="background: linear-gradient(135deg, #7c3aed, #4f46e5);">
                        <i class="fas fa-cogs" style="font-size: 2.5rem;"></i>
                    </div>
                    <div class="card-content">
                        <div class="card-header-title">
                            <?php echo e($reparation->objet_reparation); ?>

                        </div>
                        <div class="card-subtitle">
                            <i class="fas fa-car"></i> <?php echo e($reparation->vehicule->marque); ?> <?php echo e($reparation->vehicule->modele); ?>

                        </div>
                        
                        <div style="margin-bottom: 1rem;">
                            <p class="text-sm text-gray-500">
                                <i class="fas fa-user-cog"></i> <?php echo e($reparation->technicien->prenom); ?> <?php echo e($reparation->technicien->nom); ?>

                            </p>
                            <p class="text-sm text-gray-500">
                                <i class="far fa-calendar-alt"></i> <?php echo e($reparation->date->format('d/m/Y')); ?>

                            </p>
                            <p class="text-sm text-gray-500">
                                <i class="fas fa-clock"></i> <?php echo e($reparation->duree_main_oeuvre); ?>h
                            </p>
                        </div>

                        <div class="card-meta">
                            <a href="<?php echo e(route('reparations.show', $reparation)); ?>" class="btn-link">
                                Voir détails <i class="fas fa-arrow-right"></i>
                            </a>
                            <div class="flex gap-2">
                                <a href="<?php echo e(route('reparations.edit', $reparation)); ?>" class="btn-link" style="color: var(--gray-500);">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="<?php echo e(route('reparations.destroy', $reparation)); ?>" method="POST" class="inline-form" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer cette réparation ?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn-link btn-link-danger" style="padding: 0;">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ORDI\Desktop\garage\gestions_voitures\resources\views/reparations/index.blade.php ENDPATH**/ ?>