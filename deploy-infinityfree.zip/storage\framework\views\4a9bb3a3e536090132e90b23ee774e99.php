<?php $__env->startSection('title', 'Détails du Technicien'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="detail-container">
        <div class="detail-header" style="background: linear-gradient(135deg, var(--success-color), #059669);">
            <h1 class="detail-title"><i class="fas fa-user-tie"></i> <?php echo e($technicien->prenom); ?> <?php echo e($technicien->nom); ?></h1>
            <p class="detail-subtitle"><i class="fas fa-tools"></i> <?php echo e($technicien->specialite); ?></p>
            <div style="margin-top: 2rem;">
                <a href="<?php echo e(route('techniciens.edit', $technicien)); ?>" class="btn btn-secondary"><i class="fas fa-edit"></i> Modifier</a>
                <a href="<?php echo e(route('techniciens.index')); ?>" class="btn btn-gray" style="margin-left: 1rem;"><i class="fas fa-arrow-left"></i> Retour à la liste</a>
            </div>
        </div>

        <div class="detail-body">
            <h3 class="card-title" style="margin-bottom: 1.5rem; font-size: 1.5rem;"><i class="fas fa-id-card"></i> Informations Personnelles</h3>
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">Prénom</div>
                    <div class="info-value"><?php echo e($technicien->prenom); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Nom</div>
                    <div class="info-value"><?php echo e($technicien->nom); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Spécialité</div>
                    <div class="info-value"><?php echo e($technicien->specialite); ?></div>
                </div>
            </div>

            <div style="margin-top: 3rem;">
                <div class="flex-between mb-6">
                    <h3 class="card-title" style="font-size: 1.5rem;"><i class="fas fa-clipboard-list"></i> Interventions Réalisées</h3>
                    <a href="<?php echo e(route('reparations.create', ['technicien_id' => $technicien->id])); ?>" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus"></i> Ajouter une intervention
                    </a>
                </div>

                <?php if($technicien->reparations->isEmpty()): ?>
                    <div class="empty-state" style="background: var(--gray-50); box-shadow: none; border: 1px dashed var(--gray-300);">
                        <p>Aucune intervention enregistrée pour ce technicien.</p>
                    </div>
                <?php else: ?>
                    <div class="grid-container" style="grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));">
                        <?php $__currentLoopData = $technicien->reparations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reparation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="modern-card" style="box-shadow: none; border: 1px solid var(--gray-200);">
                                <div class="card-content">
                                    <div class="card-header-title" style="font-size: 1.1rem;">
                                        <?php echo e($reparation->objet_reparation); ?>

                                    </div>
                                    <div class="card-subtitle">
                                        <i class="far fa-calendar-alt"></i> <?php echo e($reparation->date->format('d/m/Y')); ?>

                                    </div>
                                    <div style="margin-bottom: 1rem;">
                                        <p class="text-sm text-gray-500">
                                            <i class="fas fa-car"></i> <?php echo e($reparation->vehicule->marque); ?> <?php echo e($reparation->vehicule->modele); ?>

                                        </p>
                                    </div>
                                    <div style="margin-top: auto;">
                                        <a href="<?php echo e(route('reparations.show', $reparation)); ?>" class="btn-link" style="margin-top: 0.5rem; display: inline-block;">
                                            Voir détails <i class="fas fa-arrow-right"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ORDI\Desktop\garage\gestions_voitures\resources\views/techniciens/show.blade.php ENDPATH**/ ?>