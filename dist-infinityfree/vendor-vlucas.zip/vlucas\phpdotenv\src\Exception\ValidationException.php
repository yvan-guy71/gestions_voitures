<?php

declare(strict_types=1);

namespace Dotenv\Exception;

use RuntimeException;

final class ValidationException extends RuntimeException implements ExceptionInterface
{
    //
}
