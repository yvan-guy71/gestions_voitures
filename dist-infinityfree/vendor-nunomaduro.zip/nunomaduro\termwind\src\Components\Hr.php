<?php

declare(strict_types=1);

namespace Termwind\Components;

final class Hr extends Element
{
    protected static array $defaultStyles = ['block', 'border-t'];
}
