<?php

namespace Illuminate\Database;

use RuntimeException;

class MultipleColumnsSelectedException extends RuntimeException
{
    //
}
