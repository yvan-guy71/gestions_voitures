<?php declare(strict_types=1);

namespace PhpParser\Node\Stmt;

require __DIR__ . '/../StaticVar.php';

if (false) {
    /**
     * For classmap-authoritative support.
     *
     * @deprecated use \PhpParser\Node\StaticVar instead.
     */
    class StaticVar extends \PhpParser\Node\StaticVar {
    }
}
